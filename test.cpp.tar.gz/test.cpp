/*void OnTime(Player* player, uint32 total, uint32 /*level/)
	{
		if (!sWorld->getBoolConfig(CONFIG_AWARDS_PER_TIME))
			return;
			
		switch (total)
		{
			case 3600: // 1 hours
				player->AddItem(sWorld->getIntConfig(CONFIG_AWARDS_PER_TIME_1_HOURS), (sWorld->getIntConfig(CONFIG_AWARDS_PER_TIME_1_HOURS_COUNT)));
				ChatHandler(player->GetSession()).SendSysMessage(LANG_PLAYER_TIME_REWARD);
				break;		
			case 10800: // 3 hours
				player->AddItem(sWorld->getIntConfig(CONFIG_AWARDS_PER_TIME_3_HOURS), (sWorld->getIntConfig(CONFIG_AWARDS_PER_TIME_3_HOURS_COUNT)));
				ChatHandler(player->GetSession()).SendSysMessage(LANG_PLAYER_TIME_REWARD);
				break;
			case 21600: // 6 hours
				player->AddItem(sWorld->getIntConfig(CONFIG_AWARDS_PER_TIME_6_HOURS), (sWorld->getIntConfig(CONFIG_AWARDS_PER_TIME_6_HOURS_COUNT))); 
				ChatHandler(player->GetSession()).SendSysMessage(LANG_PLAYER_TIME_REWARD);
				break;
			case 43200: // 12 hours
				player->AddItem(sWorld->getIntConfig(CONFIG_AWARDS_PER_TIME_12_HOURS), (sWorld->getIntConfig(CONFIG_AWARDS_PER_TIME_12_HOURS_COUNT)));
				ChatHandler(player->GetSession()).SendSysMessage(LANG_PLAYER_TIME_REWARD);
				break;
			case 86400: // 1 day
				player->AddItem(sWorld->getIntConfig(CONFIG_AWARDS_PER_TIME_1_DAY), (sWorld->getIntConfig(CONFIG_AWARDS_PER_TIME_1_DAY_COUNT)));
				ChatHandler(player->GetSession()).SendSysMessage(LANG_PLAYER_TIME_REWARD);
				break;				
			case 172800: // 2 day
				player->AddItem(sWorld->getIntConfig(CONFIG_AWARDS_PER_TIME_2_DAY), (sWorld->getIntConfig(CONFIG_AWARDS_PER_TIME_2_DAY_COUNT)));
				ChatHandler(player->GetSession()).SendSysMessage(LANG_PLAYER_TIME_REWARD);
				break;				
			case 345600: // 4 day
				player->AddItem(sWorld->getIntConfig(CONFIG_AWARDS_PER_TIME_4_DAY), (sWorld->getIntConfig(CONFIG_AWARDS_PER_TIME_4_DAY_COUNT)));
				ChatHandler(player->GetSession()).SendSysMessage(LANG_PLAYER_TIME_REWARD);
				break;				
			case 691200: // 8 day
				player->AddItem(sWorld->getIntConfig(CONFIG_AWARDS_PER_TIME_8_DAY), (sWorld->getIntConfig(CONFIG_AWARDS_PER_TIME_8_DAY_COUNT)));
				ChatHandler(player->GetSession()).SendSysMessage(LANG_PLAYER_TIME_REWARD);
				break;				
			case 1382400: // 16 day
				player->AddItem(sWorld->getIntConfig(CONFIG_AWARDS_PER_TIME_16_DAY), (sWorld->getIntConfig(CONFIG_AWARDS_PER_TIME_16_DAY_COUNT)));
				ChatHandler(player->GetSession()).SendSysMessage(LANG_PLAYER_TIME_REWARD);
				break;				
			case 2592000: // 30 day
				player->AddItem(sWorld->getIntConfig(CONFIG_AWARDS_PER_TIME_30_DAY), (sWorld->getIntConfig(CONFIG_AWARDS_PER_TIME_30_DAY_COUNT)));
				ChatHandler(player->GetSession()).SendSysMessage(LANG_PLAYER_TIME_REWARD);			
				
			case 115200: // 32 hours
				mailItems.push_back(ItemPair(5133, 1));
				mailItems.push_back(ItemPair(5133, 3));
				mailItems.push_back(ItemPair(5133, 5));
				SendMail(player, "Заголовок письма", "Содержание письма", 5000000); // Send Items +500 gold
				ChatHandler(player->GetSession()).SendSysMessage(LANG_PLAYER_TIME_REWARD);

				break;
			default:
				break;
		}
	}
};*/
